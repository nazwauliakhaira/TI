/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author DELL
 */
public class TestPolimorFisme {
    public static void main(String [] args){
        //normal----->public kendaraan
        kendaraan K1: new kendaraan(4,"Merah");
        K1 display();
        System.out.println("");
        
        //publicMobil
        Kendaraan K2 = new Mobil ("bensin,1500,4,"coklat");"
        K2 display();
        System.out.println("");
        
        //publicTruk
        Kendaraan K3 = new Truk (10000,"solar",4000,6,"biru-merah");
        K3 display();
        System.out.println("");
        
        Sepeda K4 = new SepedaListrik(2,4,2,"merah",40,50);
        K4 display();
        System.out.println("");
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author DELL
 */
public class Mobil {
      private String bahanBakar;
      private int kapasitasMesin;
      
    public Mobil(String bahanBakar,int kapasitasMesin){
        super(bahanBakar,kapasitasMesin);
    }
    public int getKapasitasMesin(){
        return kapasitasMesin;
    }
    public void setKapasitasMesin(int kapasitasMesin ){
        this.kapasitasMesin=kapasitasMesin;
    }
    public int getbahanBakar(){
        return bahanBakar;
    }
    public void setbahanBakar(int bahanBakar){
        this.bahanBakar=bahanBakar;
    }
}



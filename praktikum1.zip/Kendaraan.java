/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author DELL
 */
public class Kendaraan {
    private int jumlahRoda;
   private String warna;
    
    public Kendaraan(){
        
    }

    public String getWarna(){
        return warna;
    }
    public void setJumlahRoda (String JumlahRoda){
        this.jumlahRoda=jumlahRoda;
    }
    public int getjumlahRoda(){
        return jumlahRoda;
    }
    public void setjumlahRoda(int jumlahRoda){
    this.jumlahRoda=jumlahRoda;
    }
    public int getWarna(){
        return warna;
    }
    public void setWarna(){
        this.warna;
    }
}

